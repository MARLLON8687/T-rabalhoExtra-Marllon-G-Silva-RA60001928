function calcularNotas() {

    var valor = parseInt(document.getElementById('valor').value);


    var notas100 = 0, notas50 = 0, notas10 = 0, notas5 = 0, notas1 = 0;

    if (valor >= 100) {
        notas100 = Math.floor(valor / 100);
        valor %= 100;
    }
    if (valor >= 50) {
        notas50 = Math.floor(valor / 50);
        valor %= 50;
    }
    if (valor >= 10) {
        notas10 = Math.floor(valor / 10);
        valor %= 10;
    }
    if (valor >= 5) {
        notas5 = Math.floor(valor / 5);
        valor %= 5;
    }
    if (valor >= 1) {
        notas1 = valor;
    }

    var resultado = "Valor: R$" + document.getElementById('valor').value + "<br>";
    resultado += "Notas de 100: " + notas100 + "<br>";
    resultado += "Notas de 50: " + notas50 + "<br>";
    resultado += "Notas de 10: " + notas10 + "<br>";
    resultado += "Notas de 5: " + notas5 + "<br>";
    resultado += "Notas de 1: " + notas1 + "<br>";

    document.getElementById('resultado').innerHTML = resultado;
}