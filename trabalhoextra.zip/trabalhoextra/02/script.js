function verificarTriangulo() {

    var x = parseFloat(document.getElementById('ladoX').value);
    var y = parseFloat(document.getElementById('ladoY').value);
    var z = parseFloat(document.getElementById('ladoZ').value);

    if (x + y > z && x + z > y && y + z > x) {

        if (x === y && y === z) {
            alert("Os valores formam um triângulo equilátero.");
        } else if (x === y || x === z || y === z) {
            alert("Os valores formam um triângulo isósceles.");
        } else {
            alert("Os valores formam um triângulo escaleno.");
        }
    } else {
        alert("Os valores fornecidos não formam um triângulo.");
    }
}