function calcularCredito() {

    var saldoMedio = parseFloat(document.getElementById('saldoMedio').value);

    var percentualCredito;
    if (saldoMedio >= 0 && saldoMedio <= 200) {
        percentualCredito = 0; 
    } else if (saldoMedio <= 400) {
        percentualCredito = 20; 
    } else if (saldoMedio <= 600) {
        percentualCredito = 30; 
    } else {
        percentualCredito = 40; 
    }

    var valorCredito = saldoMedio * (percentualCredito / 100);

    var resultado = "Saldo Médio: R$" + saldoMedio.toFixed(2) + "<br>";
    resultado += "Percentual de Crédito: " + percentualCredito + "%<br>";
    resultado += "Valor do Crédito: R$" + valorCredito.toFixed(2);

    var resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = resultado;
}