function calcularValor() {

    var codigo = document.getElementById('codigo').value;
    var quantidade = parseInt(document.getElementById('quantidade').value);

    var preco;
    switch (codigo) {
        case '1':
            preco = 11.00; 
            break;
        case '2':
            preco = 8.50; 
            break;
        case '3':
            preco = 8.00; 
            break;
        case '4':
            preco = 9.00; 
            break;
        case '5':
            preco = 10.00; 
            break;
        case '6':
            preco = 4.50; 
            break;
        default:
            alert("Selecione um item válido.");
            return; 
    }

    var valorTotal = preco * quantidade;

    var resultado = "Item: " + obterNomeItem(codigo) + "<br>";
    resultado += "Preço Unitário: R$" + preco.toFixed(2) + "<br>";
    resultado += "Quantidade: " + quantidade + "<br>";
    resultado += "Valor Total: R$" + valorTotal.toFixed(2);

    var resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = resultado;
}

function obterNomeItem(codigo) {
    switch (codigo) {
        case '1':
            return "Cachorro Quente";
        case '2':
            return "Bauru";
        case '3':
            return "Misto Quente";
        case '4':
            return "Hamburguer";
        case '5':
            return "Cheeseburguer";
        case '6':
            return "Refrigerante";
        default:
            return "Item Desconhecido";
    }
}