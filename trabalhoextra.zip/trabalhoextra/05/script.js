function calcularNovoSalario() {

    var salarioAtual = parseFloat(document.getElementById('salario').value);
    var cargo = document.getElementById('cargo').value;

    var percentualAumento;
    switch (cargo) {
        case '101':
            percentualAumento = 10; 
            break;
        case '102':
            percentualAumento = 20; 
            break;
        case '103':
            percentualAumento = 30; 
            break;
        case 'outro':
            percentualAumento = 40; 
            break;
        default:
            alert("Selecione o cargo do funcionário.");
            return; 
    }

    var aumentoDecimal = percentualAumento / 100;
    var novoSalario = salarioAtual * (1 + aumentoDecimal);
    var diferenca = novoSalario - salarioAtual;

    var resultado = "Salário Antigo: R$" + salarioAtual.toFixed(2) + "<br>";
    resultado += "Novo Salário: R$" + novoSalario.toFixed(2) + "<br>";
    resultado += "Diferença: R$" + diferenca.toFixed(2);

    var resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = resultado;
}