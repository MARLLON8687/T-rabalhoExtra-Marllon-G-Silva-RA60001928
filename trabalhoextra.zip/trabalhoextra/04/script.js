function calcularImposto() {

    var anoFabricacao = parseInt(document.getElementById('anoFabricacao').value);
    var valorTabela = parseFloat(document.getElementById('valorTabela').value);

    var taxa;
    if (anoFabricacao < 1990) {
        taxa = 0.01; 
    } else {
        taxa = 0.015; 
    }

    var imposto = taxa * valorTabela;

    var resultado = "Ano de Fabricação: " + anoFabricacao + "<br>";
    resultado += "Valor de Tabela: R$" + valorTabela.toFixed(2) + "<br>";
    resultado += "Taxa de imposto aplicada: " + (taxa * 100) + "%<br>";
    resultado += "Imposto a ser pago: R$" + imposto.toFixed(2);

    document.getElementById('resultado').innerHTML = resultado;
}