function calcularSalario() {

    var nivel = parseInt(document.getElementById('nivel').value);
    var horasAula = parseFloat(document.getElementById('horasAula').value);

    var valorHoraAula;
    switch (nivel) {
        case 1:
            valorHoraAula = 12.00; 
            break;
        case 2:
            valorHoraAula = 17.00; 
            break;
        case 3:
            valorHoraAula = 25.00; 
            break;
        default:
            alert("Selecione o nível do professor.");
            return; 
    }


    var salario = valorHoraAula * horasAula * 4.5; 

    var resultado = "Nível do Professor: " + obterDescricaoNivel(nivel) + "<br>";
    resultado += "Horas/Aula por Semana: " + horasAula.toFixed(2) + "<br>";
    resultado += "Salário: R$" + salario.toFixed(2);

    var resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = resultado;
}

function obterDescricaoNivel(nivel) {
    switch (nivel) {
        case 1:
            return "Professor Nível 1";
        case 2:
            return "Professor Nível 2";
        case 3:
            return "Professor Nível 3";
        default:
            return "";
    }
}