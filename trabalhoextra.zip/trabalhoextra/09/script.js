function calcularValor() {

    var preco = parseFloat(document.getElementById('preco').value);
    var condicao = document.getElementById('condicao').value;

    var valorFinal;
    switch (condicao) {
        case 'a':
            valorFinal = preco * 0.9; 
            break;
        case 'b':
            valorFinal = preco * 0.85; 
            break;
        case 'c':
            valorFinal = preco; 
            break;
        case 'd':
            valorFinal = preco * 1.1; 
            break;
        default:
            alert("Selecione a condição de pagamento.");
            return; 
    }


    var resultado = "Preço de Etiqueta: R$" + preco.toFixed(2) + "<br>";
    resultado += "Condição de Pagamento: " + obterDescricaoCondicao(condicao) + "<br>";
    resultado += "Valor a Pagar: R$" + valorFinal.toFixed(2);


    var resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = resultado;
}

function obterDescricaoCondicao(condicao) {
    switch (condicao) {
        case 'a':
            return "À vista em dinheiro ou cheque (10% de desconto)";
        case 'b':
            return "À vista no cartão de crédito (15% de desconto)";
        case 'c':
            return "Em duas vezes sem juros";
        case 'd':
            return "Em duas vezes com juros (10%)";
        default:
            return "";
    }
}